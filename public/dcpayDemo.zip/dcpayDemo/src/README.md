# DCPAY Java Demo

DCPAY API 的 Java 示例代码，涵盖代收下单、代付下单、订单查询、余额查询四个接口，以及回调通知接收示例。

## 环境要求

- Java 11+（使用了 `java.net.http.HttpClient`）
- 无需第三方依赖

## 目录结构

```
src/
├── pay/                         # 代收下单
│   ├── DcPayClient.java         # 客户端（签名、请求、解析）
│   ├── PayRequest.java          # 请求参数
│   ├── PayResponse.java         # 响应结果
│   └── PayExample.java          # 调用示例
├── transfer/                    # 代付下单
│   ├── TransferClient.java
│   ├── TransferRequest.java
│   ├── TransferResponse.java
│   └── TransferExample.java
├── queryOrder/                  # 订单查询
│   ├── QueryOrderClient.java
│   ├── QueryOrderRequest.java
│   ├── QueryOrderResponse.java
│   └── QueryOrderExample.java
├── queryBalance/                # 商户余额查询
│   ├── QueryBalanceClient.java
│   ├── QueryBalanceRequest.java
│   ├── QueryBalanceResponse.java
│   └── QueryBalanceExample.java
└── notifyUrlController/         # 回调通知接收（Spring Boot）
    └── NotifyController.java    # 接收 DCPAY 回调的 Controller 示例
```

## 编译与运行

在 `dcpayDemo/` 根目录下执行：

```bash
# 编译所有文件
javac -d out $(find src -name "*.java")

# 运行代收下单示例
java -cp out src.pay.PayExample

# 运行代付下单示例
java -cp out src.transfer.TransferExample

# 运行订单查询示例
java -cp out src.queryOrder.QueryOrderExample

# 运行余额查询示例
java -cp out src.queryBalance.QueryBalanceExample
```

> `notifyUrlController/NotifyController.java` 是 Spring Boot Controller，需集成到 Spring Boot 项目中使用，不能直接通过命令行运行。

## 使用说明

每个 `*Example.java` 文件中需要配置以下参数：

| 参数 | 说明 |
|------|------|
| `baseUrl` | API 地址，固定为 `https://api.dcpay.me` |
| `mchNo` | 商户号，登录商户端获取 |
| `privateKey` | 商户私钥（PEM 格式），登录商户端 → 设置 → 商户私钥 |

`NotifyController.java` 中需要配置：

| 参数 | 说明 |
|------|------|
| `PLATFORM_PUBLIC_KEY` | 平台公钥（PEM 格式），登录商户端 → 设置 → 平台公钥，用于验证回调签名 |

## 签名说明

所有接口使用 **RSA2（SHA256WithRSA）** 签名：

1. 将请求参数按参数名 ASCII 升序排列
2. 过滤空值和 `sign` 字段，拼接为 `key=value&key=value` 格式
3. 使用商户私钥对字符串进行签名，结果 Base64 编码后作为 `sign` 参数

回调通知验签使用**平台公钥**，算法相同。

## 接口列表

| 接口 | 路径 | 说明 |
|------|------|------|
| 代收下单 | `POST /unipay/pay` | 发起收款订单 |
| 代付下单 | `POST /unipay/transfer` | 向银行账户转账 |
| 订单查询 | `POST /unipay/queryOrder` | 查询代收或代付订单状态 |
| 余额查询 | `POST /unipay/queryBalance` | 查询商户账户各类余额 |

## 回调通知

DCPAY 在订单状态变更时，会向下单时填写的 `notifyUrl` 发送 GET 请求。

回调参数：

| 参数 | 必有 | 说明 |
|------|------|------|
| `mchNo` | 是 | 商户号 |
| `bizOrderNo` | 是 | 商户订单号 |
| `orderNo` | 是 | DCPAY 订单号 |
| `amount` | 是 | 订单金额 |
| `status` | 是 | 订单状态：`success` / `fail` / `closed` |
| `sign` | 是 | 签名值，使用平台公钥验签 |
| `title` | 否 | 订单标题，下单时选填 |
| `payTime` | 否 | 支付完成时间（13位毫秒时间戳） |

商户处理完业务后必须返回字符串 `SUCCESS`，否则 DCPAY 会按梯度间隔重试，最多重试 16 次。
