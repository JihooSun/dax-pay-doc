package src.queryOrder;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QueryOrderClient {

    private final String baseUrl;
    private final String privateKey;
    private final HttpClient httpClient;

    public QueryOrderClient(String baseUrl, String privateKey) {
        this.baseUrl = baseUrl;
        this.privateKey = privateKey;
        this.httpClient = HttpClient.newHttpClient();
    }

    public QueryOrderResponse queryOrder(QueryOrderRequest request) throws Exception {
        request.setReqTime(System.currentTimeMillis());

        String signStr = buildSignString(request);
        System.out.println("待签名字符串: " + signStr);

        String sign = rsa2Sign(signStr, privateKey);
        request.setSign(sign);

        String jsonBody = toJson(request);
        System.out.println("请求JSON: " + jsonBody);
        System.out.println();

        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/unipay/queryOrder"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody, StandardCharsets.UTF_8))
                .build();

        HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));

        System.out.println("响应状态码: " + response.statusCode());
        System.out.println("响应内容: " + response.body());

        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP请求失败, 状态码: " + response.statusCode() + ", 响应: " + response.body());
        }

        return parseResponse(response.body());
    }

    public static String rsa2Sign(String data, String privateKeyStr) throws Exception {
        String privateKeyPEM = privateKeyStr
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("-----END PRIVATE KEY-----", "")
                .replaceAll("\\s+", "");

        byte[] keyBytes = Base64.getDecoder().decode(privateKeyPEM);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        PrivateKey privateKey = KeyFactory.getInstance("RSA").generatePrivate(keySpec);

        Signature signature = Signature.getInstance("SHA256WithRSA");
        signature.initSign(privateKey);
        signature.update(data.getBytes(StandardCharsets.UTF_8));

        return Base64.getEncoder().encodeToString(signature.sign());
    }

    public static String buildSignString(QueryOrderRequest request) {
        Map<String, String> params = new HashMap<>();
        params.put("mchNo", request.getMchNo());
        if (request.getReqTime() != null) {
            params.put("reqTime", String.valueOf(request.getReqTime()));
        }
        if (request.getQueryType() != null) {
            params.put("queryType", request.getQueryType());
        }
        if (request.getBizOrderNo() != null) {
            params.put("bizOrderNo", request.getBizOrderNo());
        }
        if (request.getOrderNo() != null) {
            params.put("orderNo", request.getOrderNo());
        }
        return buildSignString(params);
    }

    public static String buildSignString(Map<String, String> params) {
        List<String> keys = new ArrayList<>(params.keySet());
        Collections.sort(keys);

        StringBuilder sb = new StringBuilder();
        for (String key : keys) {
            String value = params.get(key);
            if (value != null && !value.isEmpty() && !"sign".equals(key)) {
                if (sb.length() > 0) sb.append("&");
                sb.append(key).append("=").append(value);
            }
        }
        return sb.toString();
    }

    private String toJson(QueryOrderRequest request) {
        List<String> fields = new ArrayList<>();
        addField(fields, "mchNo", request.getMchNo());
        if (request.getReqTime() != null) {
            fields.add("\"reqTime\": " + request.getReqTime());
        }
        addField(fields, "sign", request.getSign());
        addField(fields, "queryType", request.getQueryType());
        addField(fields, "bizOrderNo", request.getBizOrderNo());
        addField(fields, "orderNo", request.getOrderNo());

        return "{" + String.join(", ", fields) + "}";
    }

    private void addField(List<String> fields, String name, String value) {
        if (value != null) {
            fields.add("\"" + name + "\": \"" + escapeJson(value) + "\"");
        }
    }

    private String escapeJson(String value) {
        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private QueryOrderResponse parseResponse(String json) {
        QueryOrderResponse response = new QueryOrderResponse();

        String codeStr = extractNumericField(json, "code");
        if (codeStr != null) {
            response.setCode(Integer.parseInt(codeStr));
        }
        response.setMsg(extractStringField(json, "msg"));

        String dataJson = extractObjectField(json, "data");
        if (dataJson != null) {
            QueryOrderResponse.QueryData data = new QueryOrderResponse.QueryData();
            data.setBizOrderNo(extractStringField(dataJson, "bizOrderNo"));
            data.setOrderNo(extractStringField(dataJson, "orderNo"));
            data.setStatus(extractStringField(dataJson, "status"));
            data.setOrderAmount(extractStringField(dataJson, "orderAmount"));
            response.setData(data);
        }

        return response;
    }

    private String extractObjectField(String json, String fieldName) {
        String pattern = "\"" + fieldName + "\"";
        int start = json.indexOf(pattern);
        if (start == -1) return null;
        start += pattern.length();
        while (start < json.length() && (json.charAt(start) == ' ' || json.charAt(start) == ':' || json.charAt(start) == '\t' || json.charAt(start) == '\n')) start++;
        if (start >= json.length() || json.charAt(start) != '{') return null;
        start++;
        int braceCount = 1, end = start;
        while (end < json.length() && braceCount > 0) {
            char c = json.charAt(end);
            if (c == '{') braceCount++;
            else if (c == '}') braceCount--;
            end++;
        }
        return json.substring(start, end - 1);
    }

    private String extractStringField(String json, String fieldName) {
        String pattern = "\"" + fieldName + "\"";
        int start = json.indexOf(pattern);
        if (start == -1) return null;
        start += pattern.length();
        while (start < json.length() && (json.charAt(start) == ' ' || json.charAt(start) == ':' || json.charAt(start) == '\t' || json.charAt(start) == '\n')) start++;
        if (start >= json.length() || json.charAt(start) != '"') return null;
        start++;
        int end = start;
        while (end < json.length()) {
            char c = json.charAt(end);
            if (c == '\\' && end + 1 < json.length()) { end += 2; continue; }
            if (c == '"') break;
            end++;
        }
        return json.substring(start, end).replace("\\\"", "\"").replace("\\\\", "\\").replace("\\n", "\n").replace("\\r", "\r").replace("\\t", "\t");
    }

    private String extractNumericField(String json, String fieldName) {
        String pattern = "\"" + fieldName + "\"";
        int start = json.indexOf(pattern);
        if (start == -1) return null;
        start += pattern.length();
        while (start < json.length() && (json.charAt(start) == ' ' || json.charAt(start) == ':' || json.charAt(start) == '\t' || json.charAt(start) == '\n')) start++;
        int end = start;
        while (end < json.length() && (Character.isDigit(json.charAt(end)) || json.charAt(end) == '.' || json.charAt(end) == '-')) end++;
        return json.substring(start, end).trim();
    }
}
