package src.queryOrder;

public class QueryOrderRequest {
    private String mchNo;
    private Long reqTime;
    private String sign;
    private String queryType;
    private String bizOrderNo;
    private String orderNo;

    public String getMchNo() { return mchNo; }
    public void setMchNo(String mchNo) { this.mchNo = mchNo; }

    public Long getReqTime() { return reqTime; }
    public void setReqTime(Long reqTime) { this.reqTime = reqTime; }

    public String getSign() { return sign; }
    public void setSign(String sign) { this.sign = sign; }

    public String getQueryType() { return queryType; }
    public void setQueryType(String queryType) { this.queryType = queryType; }

    public String getBizOrderNo() { return bizOrderNo; }
    public void setBizOrderNo(String bizOrderNo) { this.bizOrderNo = bizOrderNo; }

    public String getOrderNo() { return orderNo; }
    public void setOrderNo(String orderNo) { this.orderNo = orderNo; }
}
