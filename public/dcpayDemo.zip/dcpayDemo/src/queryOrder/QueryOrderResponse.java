package src.queryOrder;

public class QueryOrderResponse {
    private Integer code;
    private String msg;
    private QueryData data;

    public Integer getCode() { return code; }
    public void setCode(Integer code) { this.code = code; }

    public String getMsg() { return msg; }
    public void setMsg(String msg) { this.msg = msg; }

    public QueryData getData() { return data; }
    public void setData(QueryData data) { this.data = data; }

    public static class QueryData {
        private String bizOrderNo;
        private String orderNo;
        private String status;
        private String orderAmount;

        public String getBizOrderNo() { return bizOrderNo; }
        public void setBizOrderNo(String bizOrderNo) { this.bizOrderNo = bizOrderNo; }

        public String getOrderNo() { return orderNo; }
        public void setOrderNo(String orderNo) { this.orderNo = orderNo; }

        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }

        public String getOrderAmount() { return orderAmount; }
        public void setOrderAmount(String orderAmount) { this.orderAmount = orderAmount; }

        @Override
        public String toString() {
            return "QueryData{" +
                    "bizOrderNo='" + bizOrderNo + '\'' +
                    ", orderNo='" + orderNo + '\'' +
                    ", status='" + status + '\'' +
                    ", orderAmount='" + orderAmount + '\'' +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "QueryOrderResponse{code=" + code + ", msg='" + msg + "', data=" + data + '}';
    }
}
