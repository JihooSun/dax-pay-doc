package src.queryBalance;

public class QueryBalanceExample {

    public static void main(String[] args) throws Exception {
        String baseUrl = "https://api.dcpay.me";
        String privateKey = "-----BEGIN PRIVATE KEY-----\n" +
                "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAJwfnFLiEq2SyLgY\n" +
                "fSSNv2yQ/PDmvQQ21MRLQvga3guxfql6582MPQGiV49EKCY6z4OfGsGbALmVQt1Y\n" +
                "pbRq1bnqW0qUuG1K8ZHK+M4GpGgipVjPgCO5SKkYol2364DLKevxddB4F8ehVL07\n" +
                "cC/QiN0uNgsHtIsSy18l2Lfq31I3AgMBAAECgYAh9f5bSTIm77cZ1LnkKbFqPF/J\n" +
                "R2f2crb1vCllLvL+OC4FT+b8n3Tl1hqV342cQ07Aout/EeimdgGFhLMG+/Zhk81g\n" +
                "NByjRDUkayMy2x1mNVOA8lB7VkTREKPyAEGwt4aLumxGI3AzrgAhDVXi9R4qaSRu\n" +
                "ve8YBubbiYNrmLbGgQJBAMp6TEC1Z67CVT6uitExOTcfihNuvmqGBxtF+l4V+icq\n" +
                "RykC/FfMXnfafbbbbAK42UdIRZKSMZKaPHFVtXMXKGMCQQDFZINUWxiO0SD14t09\n" +
                "xw5neDDkjdiwKH+zbieDbclrjc62x0o4BzBOL5ADKeCgG+AkuQz1B4Wj1t/A4pg6\n" +
                "0/UdAkAb1vLzFr45ziiQZMlbeAwo4yJGB70QwnrpqhaBpz3s8qg0IF/35na6vgT5\n" +
                "BnR0b1wYq/w86fL8+E4FO0amm3GHAkB/OUlsFUq+wgt8b7wpFSMzjUP2C3aeE3w7\n" +
                "KcRN8XTg3YVeSRSNCBUaT42CfHtKtqzA/oRbaX25G8UbjPCQ+gwBAkBsbCfGqVkD\n" +
                "42aQP3HSn41F6EhpuK2IXtWGCjt0tdGt0ekbKNHS0H04rfYS/pjKuiZ+Y50xmtgL\n" +
                "YoLNVkiIx8i5\n" +
                "-----END PRIVATE KEY-----";

        QueryBalanceClient client = new QueryBalanceClient(baseUrl, privateKey);

        QueryBalanceRequest request = new QueryBalanceRequest();
        request.setMchNo("DC1010");
        request.setClientIp("127.0.0.1"); // 选填

        System.out.println("=== 发起余额查询 ===");
        System.out.println("商户号: " + request.getMchNo());
        System.out.println();

        try {
            QueryBalanceResponse response = client.queryBalance(request);
            System.out.println("=== 查询响应 ===");
            System.out.println("响应码: " + response.getCode());
            System.out.println("响应消息: " + response.getMsg());
            if (response.getData() != null) {
                QueryBalanceResponse.BalanceData data = response.getData();
                System.out.println("可提现余额（分）: " + data.getWithdrawableAmount());
                System.out.println("待结算余额（分）: " + data.getPendingAmount());
                System.out.println("代付冻结余额（分）: " + data.getPayoutFrozenAmount());
                System.out.println("提现冻结余额（分）: " + data.getWithdrawFrozenAmount());
            }
        } catch (Exception e) {
            System.err.println("查询失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
