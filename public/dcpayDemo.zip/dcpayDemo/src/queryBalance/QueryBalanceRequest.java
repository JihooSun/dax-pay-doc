package src.queryBalance;

public class QueryBalanceRequest {
    private String mchNo;
    private Long reqTime;
    private String sign;
    private String clientIp;

    public String getMchNo() { return mchNo; }
    public void setMchNo(String mchNo) { this.mchNo = mchNo; }

    public Long getReqTime() { return reqTime; }
    public void setReqTime(Long reqTime) { this.reqTime = reqTime; }

    public String getSign() { return sign; }
    public void setSign(String sign) { this.sign = sign; }

    public String getClientIp() { return clientIp; }
    public void setClientIp(String clientIp) { this.clientIp = clientIp; }
}
