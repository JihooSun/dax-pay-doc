package src.queryBalance;

public class QueryBalanceResponse {
    private Integer code;
    private String msg;
    private BalanceData data;

    public Integer getCode() { return code; }
    public void setCode(Integer code) { this.code = code; }

    public String getMsg() { return msg; }
    public void setMsg(String msg) { this.msg = msg; }

    public BalanceData getData() { return data; }
    public void setData(BalanceData data) { this.data = data; }

    public static class BalanceData {
        private Long withdrawableAmount;
        private Long pendingAmount;
        private Long payoutFrozenAmount;
        private Long withdrawFrozenAmount;

        public Long getWithdrawableAmount() { return withdrawableAmount; }
        public void setWithdrawableAmount(Long withdrawableAmount) { this.withdrawableAmount = withdrawableAmount; }

        public Long getPendingAmount() { return pendingAmount; }
        public void setPendingAmount(Long pendingAmount) { this.pendingAmount = pendingAmount; }

        public Long getPayoutFrozenAmount() { return payoutFrozenAmount; }
        public void setPayoutFrozenAmount(Long payoutFrozenAmount) { this.payoutFrozenAmount = payoutFrozenAmount; }

        public Long getWithdrawFrozenAmount() { return withdrawFrozenAmount; }
        public void setWithdrawFrozenAmount(Long withdrawFrozenAmount) { this.withdrawFrozenAmount = withdrawFrozenAmount; }

        @Override
        public String toString() {
            return "BalanceData{" +
                    "withdrawableAmount=" + withdrawableAmount +
                    ", pendingAmount=" + pendingAmount +
                    ", payoutFrozenAmount=" + payoutFrozenAmount +
                    ", withdrawFrozenAmount=" + withdrawFrozenAmount +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "QueryBalanceResponse{code=" + code + ", msg='" + msg + "', data=" + data + '}';
    }
}
