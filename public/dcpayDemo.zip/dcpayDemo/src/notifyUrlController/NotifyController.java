package src.notifyUrlController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;

/**
 * 商户侧回调通知接收示例（Spring Boot）
 *
 * DCPAY 在订单状态变更时，会向下单时填写的 notifyUrl 发送 GET 请求。
 * 商户需要：
 *   1. 验证签名（使用平台公钥）
 *   2. 处理业务逻辑
 *   3. 返回字符串 "SUCCESS"（不区分大小写），否则 DCPAY 会重试
 *
 * 回调参数（GET query string）：
 *   mchNo       - 商户号（必有）
 *   bizOrderNo  - 商户订单号（必有）
 *   orderNo     - DCPAY 订单号（必有）
 *   amount      - 订单金额（必有）
 *   status      - 订单状态：success / fail / closed（必有）
 *   title       - 订单标题（可能为空，下单时选填）
 *   payTime     - 支付完成时间，13位毫秒时间戳（可能为空）
 *   sign        - 签名值，使用平台公钥验签（必有）
 */
@RestController
@RequestMapping("/notify")
public class NotifyController {

    // 平台公钥（从商户端 -> 设置 页面获取）
    private static final String PLATFORM_PUBLIC_KEY =
            "-----BEGIN PUBLIC KEY-----\n" +
            "您的平台公钥内容...\n" +
            "-----END PUBLIC KEY-----";

    /**
     * 接收 DCPAY 回调通知
     * notifyUrl 示例: https://your-domain.com/notify
     */
    @GetMapping
    public String notify(@RequestParam Map<String, String> params) {
        try {
            String sign       = params.get("sign");
            String mchNo      = params.get("mchNo");
            String bizOrderNo = params.get("bizOrderNo");
            String orderNo    = params.get("orderNo");
            String status     = params.get("status");
            String amount     = params.get("amount");
            String title      = params.get("title");    // 可能为空
            String payTime    = params.get("payTime");  // 可能为空

            System.out.println("=== 收到回调通知 ===");
            System.out.println("商户号: " + mchNo);
            System.out.println("商户订单号: " + bizOrderNo);
            System.out.println("DCPAY订单号: " + orderNo);
            System.out.println("订单状态: " + status);
            System.out.println("金额: " + amount);
            System.out.println("标题: " + title);
            System.out.println("支付时间: " + payTime);

            // 1. 验证签名
            if (sign == null || sign.isEmpty()) {
                System.out.println("签名为空，拒绝处理");
                return "FAIL";
            }
            if (!verifySign(params, sign, PLATFORM_PUBLIC_KEY)) {
                System.out.println("签名验证失败，拒绝处理");
                return "FAIL";
            }
            System.out.println("签名验证通过");

            // 2. 处理业务逻辑
            // 注意：回调中没有 noticeType 字段，无法直接区分代收/代付
            // 可根据 orderNo 前缀判断，或在本地数据库中通过 bizOrderNo 查询订单类型
            handleOrderNotice(bizOrderNo, orderNo, status, amount);

            // 3. 返回 SUCCESS，告知 DCPAY 通知已处理，停止重试
            return "SUCCESS";
        } catch (Exception e) {
            System.err.println("处理回调异常: " + e.getMessage());
            e.printStackTrace();
            return "FAIL";
        }
    }

    /**
     * 处理订单回调
     * 回调中无 noticeType 字段，建议通过本地数据库查询 bizOrderNo 对应的订单类型来区分代收/代付
     */
    private void handleOrderNotice(String bizOrderNo, String orderNo, String status, String amount) {
        System.out.println("=== 处理订单回调 ===");
        if ("success".equals(status)) {
            // TODO: 查询本地订单类型，更新状态为成功，执行后续业务（发货、结算等）
            System.out.println("订单成功，商户订单号: " + bizOrderNo + "，金额: " + amount);
        } else if ("fail".equals(status)) {
            // TODO: 更新本地订单状态为失败
            System.out.println("订单失败，商户订单号: " + bizOrderNo);
        } else if ("closed".equals(status)) {
            // TODO: 更新本地订单状态为已关闭
            System.out.println("订单已关闭，商户订单号: " + bizOrderNo);
        }
    }

    /**
     * RSA2 验签（SHA256WithRSA）
     *
     * 签名规则（与服务端 PaySignUtil.createLinkString 保持一致）：
     *   1. 去掉 sign 字段，过滤空值
     *   2. 按参数名 ASCII 升序排列
     *   3. 拼接为 key=value&key=value，去掉 " 和 \ 字符
     *   4. 使用平台公钥验签
     */
    private boolean verifySign(Map<String, String> params, String sign, String publicKeyPem) throws Exception {
        List<String> keys = new ArrayList<>(params.keySet());
        Collections.sort(keys);
        StringBuilder sb = new StringBuilder();
        for (String key : keys) {
            if ("sign".equals(key)) continue;
            String value = params.get(key);
            if (value == null || value.isEmpty()) continue;
            if (sb.length() > 0) sb.append("&");
            sb.append(key).append("=").append(value);
        }
        // 与服务端 createLinkString 保持一致：去掉 " 和 \ 字符
        String signStr = sb.toString().replace("\\", "").replace("\"", "");
        System.out.println("待验签字符串: " + signStr);

        String processedKey = publicKeyPem
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replace("-----END PUBLIC KEY-----", "")
                .replaceAll("\\s+", "");
        byte[] keyBytes = Base64.getDecoder().decode(processedKey);
        PublicKey publicKey = KeyFactory.getInstance("RSA")
                .generatePublic(new X509EncodedKeySpec(keyBytes));

        Signature signature = Signature.getInstance("SHA256WithRSA");
        signature.initVerify(publicKey);
        signature.update(signStr.getBytes(StandardCharsets.UTF_8));
        return signature.verify(Base64.getDecoder().decode(sign));
    }
}
