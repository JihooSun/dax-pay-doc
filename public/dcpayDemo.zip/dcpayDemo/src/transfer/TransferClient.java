package src.transfer;

import java.math.BigDecimal;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.Duration;
import java.util.Base64;
import java.util.Map;
import java.util.TreeMap;

public class TransferClient {
    private final String baseUrl;
    private final PrivateKey privateKey;
    private final HttpClient httpClient;

    public TransferClient(String baseUrl, String privateKeyPem) throws Exception {
        this.baseUrl = baseUrl;
        this.privateKey = loadPrivateKey(privateKeyPem);
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(30))
                .build();
    }

    public TransferResponse transfer(TransferRequest request) throws Exception {
        request.setReqTime(System.currentTimeMillis());
        
        String signString = buildSignString(request);
        System.out.println("待签名字符串: " + signString);
        
        String sign = sign(signString);
        request.setSign(sign);
        
        String jsonBody = buildJsonBody(request);
        System.out.println("请求体: " + jsonBody);
        
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/unipay/transfer"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();
        
        HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
        System.out.println("响应体: " + response.body());
        
        return parseResponse(response.body());
    }

    private PrivateKey loadPrivateKey(String privateKeyPem) throws Exception {
        String privateKeyContent = privateKeyPem
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("-----END PRIVATE KEY-----", "")
                .replaceAll("\\s", "");
        
        byte[] keyBytes = Base64.getDecoder().decode(privateKeyContent);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(spec);
    }

    private String sign(String data) throws Exception {
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(privateKey);
        signature.update(data.getBytes("UTF-8"));
        return Base64.getEncoder().encodeToString(signature.sign());
    }

    public static String buildSignString(TransferRequest request) {
        Map<String, String> params = new TreeMap<>();
        params.put("mchNo", request.getMchNo());
        params.put("bizOrderNo", request.getBizOrderNo());
        if (request.getAmount() != null) {
            params.put("amount", request.getAmount().stripTrailingZeros().toPlainString());
        }
        params.put("currency", request.getCurrency());
        if (request.getReqTime() != null) {
            params.put("reqTime", String.valueOf(request.getReqTime()));
        }
        if (request.getTitle() != null) {
            params.put("title", request.getTitle());
        }
        if (request.getClientIp() != null) {
            params.put("clientIp", request.getClientIp());
        }
        if (request.getNotifyUrl() != null) {
            params.put("notifyUrl", request.getNotifyUrl());
        }
        if (request.getReturnUrl() != null) {
            params.put("returnUrl", request.getReturnUrl());
        }
        if (request.getExpiredTime() != null) {
            params.put("expiredTime", String.valueOf(request.getExpiredTime()));
        }
        if (request.getExtraParam() != null) {
            params.put("extraParam", request.getExtraParam());
        }
        if (request.getBankName() != null) {
            params.put("bankName", request.getBankName());
        }
        if (request.getBranchName() != null) {
            params.put("branchName", request.getBranchName());
        }
        if (request.getBankAddress() != null) {
            params.put("bankAddress", request.getBankAddress());
        }
        if (request.getAccountNo() != null) {
            params.put("accountNo", request.getAccountNo());
        }
        if (request.getAccountName() != null) {
            params.put("accountName", request.getAccountName());
        }
        if (request.getIfscCode() != null) {
            params.put("ifscCode", request.getIfscCode());
        }
        if (request.getNumber() != null) {
            params.put("number", request.getNumber());
        }
        if (request.getTransferMode() != null) {
            params.put("transferMode", request.getTransferMode());
        }
        if (request.getVpa() != null) {
            params.put("vpa", request.getVpa());
        }
        
        return buildSignString(params);
    }

    private static String buildSignString(Map<String, String> params) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (entry.getValue() != null && !entry.getValue().isEmpty()) {
                if (sb.length() > 0) {
                    sb.append("&");
                }
                sb.append(entry.getKey()).append("=").append(entry.getValue());
            }
        }
        return sb.toString();
    }

    // 这个方法一般使用gson这样的三方组件实现
    private String buildJsonBody(TransferRequest request) {
        StringBuilder json = new StringBuilder();
        json.append("{");
        appendField(json, "mchNo", request.getMchNo(), true);
        appendField(json, "bizOrderNo", request.getBizOrderNo(), false);
        if (request.getAmount() != null) {
            appendField(json, "amount", request.getAmount().stripTrailingZeros().toPlainString(), false, false);
        }
        appendField(json, "currency", request.getCurrency(), false);
        appendField(json, "reqTime", String.valueOf(request.getReqTime()), false, false);
        appendField(json, "sign", request.getSign(), false);
        appendField(json, "title", request.getTitle(), false);
        appendField(json, "clientIp", request.getClientIp(), false);
        appendField(json, "notifyUrl", request.getNotifyUrl(), false);
        appendField(json, "returnUrl", request.getReturnUrl(), false);
        if (request.getExpiredTime() != null) {
            appendField(json, "expiredTime", String.valueOf(request.getExpiredTime()), false, false);
        }
        appendField(json, "extraParam", request.getExtraParam(), false);
        appendField(json, "bankName", request.getBankName(), false);
        appendField(json, "branchName", request.getBranchName(), false);
        appendField(json, "bankAddress", request.getBankAddress(), false);
        appendField(json, "accountNo", request.getAccountNo(), false);
        appendField(json, "accountName", request.getAccountName(), false);
        appendField(json, "ifscCode", request.getIfscCode(), false);
        appendField(json, "number", request.getNumber(), false);
        appendField(json, "transferMode", request.getTransferMode(), false);
        appendField(json, "vpa", request.getVpa(), false);
        // 只有当最后一个字符是逗号时才移除
        if (json.length() > 1 && json.charAt(json.length() - 1) == ',') {
            json.setLength(json.length() - 1);
        }
        json.append("}");
        return json.toString();
    }

    private void appendField(StringBuilder json, String key, String value, boolean isFirst) {
        appendField(json, key, value, isFirst, true);
    }

    private void appendField(StringBuilder json, String key, String value, boolean isFirst, boolean isString) {
        if (value == null || value.isEmpty()) {
            return;
        }
        if (!isFirst) {
            json.append(",");
        }
        json.append("\"").append(key).append("\":");
        if (isString) {
            json.append("\"").append(escapeJson(value)).append("\"");
        } else {
            json.append(value);
        }
    }

    private String escapeJson(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }

    private TransferResponse parseResponse(String json) {
        TransferResponse response = new TransferResponse();
        try {
            json = json.trim();
            
            // 解析code
            int codeStart = json.indexOf("\"code\":");
            if (codeStart != -1) {
                int codeEnd = json.indexOf(",", codeStart);
                if (codeEnd == -1) codeEnd = json.indexOf("}", codeStart);
                String codeStr = json.substring(codeStart + 7, codeEnd).trim();
                response.setCode(Integer.parseInt(codeStr));
            }
            
            // 解析msg
            int msgStart = json.indexOf("\"msg\":");
            if (msgStart != -1) {
                int msgValueStart = json.indexOf("\"", msgStart + 6) + 1;
                int msgValueEnd = json.indexOf("\"", msgValueStart);
                response.setMsg(json.substring(msgValueStart, msgValueEnd));
            }
            
            // 解析data对象
            int dataStart = json.indexOf("\"data\":");
            if (dataStart != -1) {
                int dataValueStart = json.indexOf("{", dataStart);
                int dataValueEnd = json.lastIndexOf("}");
                if (dataValueStart != -1 && dataValueEnd != -1 && dataValueEnd > dataValueStart) {
                    String dataJson = json.substring(dataValueStart, dataValueEnd + 1);
                    TransferResponse.TransferData data = parseData(dataJson);
                    response.setData(data);
                }
            }
        } catch (Exception e) {
            System.err.println("解析响应失败: " + e.getMessage());
        }
        return response;
    }
    
    // 这个方法一般使用gson这样的三方组件实现
    private TransferResponse.TransferData parseData(String json) {
        TransferResponse.TransferData data = new TransferResponse.TransferData();
        try {
            // 解析bizOrderNo
            String bizOrderNo = extractStringValue(json, "bizOrderNo");
            if (bizOrderNo != null) {
                data.setBizOrderNo(bizOrderNo);
            }
            
            // 解析orderNo
            String orderNo = extractStringValue(json, "orderNo");
            if (orderNo != null) {
                data.setOrderNo(orderNo);
            }
            
            // 解析status
            String status = extractStringValue(json, "status");
            if (status != null) {
                data.setStatus(status);
            }
            
            // 解析payData
            String payData = extractStringValue(json, "payData");
            data.setPayData(payData);
            
            // 解析extraParam
            String extraParam = extractStringValue(json, "extraParam");
            data.setExtraParam(extraParam);
            
            // 解析amount
            int amountStart = json.indexOf("\"amount\":");
            if (amountStart != -1) {
                int amountValueStart = amountStart + 9;
                int amountEnd = json.length() - 1;
                // 找到amount值结束位置
                for (int i = amountValueStart; i < json.length(); i++) {
                    char c = json.charAt(i);
                    if (c == ',' || c == '}' || c == ' ') {
                        amountEnd = i;
                        break;
                    }
                }
                String amountStr = json.substring(amountValueStart, amountEnd).trim();
                if (!amountStr.equals("null") && !amountStr.isEmpty()) {
                    data.setAmount(new BigDecimal(amountStr));
                }
            }
        } catch (Exception e) {
            System.err.println("解析data失败: " + e.getMessage());
        }
        return data;
    }
    
    private String extractStringValue(String json, String fieldName) {
        String searchStr = "\"" + fieldName + "\":";
        int start = json.indexOf(searchStr);
        if (start == -1) return null;
        
        int valueStart = json.indexOf("\"", start + searchStr.length());
        if (valueStart == -1) {
            // 可能是null值
            int nullStart = start + searchStr.length();
            String possibleNull = json.substring(nullStart, Math.min(nullStart + 4, json.length())).trim();
            if (possibleNull.startsWith("null")) {
                return null;
            }
            return null;
        }
        
        int valueEnd = json.indexOf("\"", valueStart + 1);
        if (valueEnd == -1) return null;
        
        return json.substring(valueStart + 1, valueEnd);
    }
}
