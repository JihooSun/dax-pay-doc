package src.pay;
import java.math.BigDecimal;

public class PayResponse {
    private Integer code;
    private String msg;
    private PayData data;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public PayData getData() {
        return data;
    }

    public void setData(PayData data) {
        this.data = data;
    }

    public static class PayData {
        private String bizOrderNo;
        private String orderNo;
        private String status;
        private String payData;
        private String extraParam;
        private BigDecimal amount;

        public String getBizOrderNo() {
            return bizOrderNo;
        }

        public void setBizOrderNo(String bizOrderNo) {
            this.bizOrderNo = bizOrderNo;
        }

        public String getOrderNo() {
            return orderNo;
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getPayData() {
            return payData;
        }

        public void setPayData(String payData) {
            this.payData = payData;
        }

        public String getExtraParam() {
            return extraParam;
        }

        public void setExtraParam(String extraParam) {
            this.extraParam = extraParam;
        }

        public BigDecimal getAmount() {
            return amount;
        }

        public void setAmount(BigDecimal amount) {
            this.amount = amount;
        }

        @Override
        public String toString() {
            return "PayData{" +
                    "bizOrderNo='" + bizOrderNo + '\'' +
                    ", orderNo='" + orderNo + '\'' +
                    ", status='" + status + '\'' +
                    ", payData='" + payData + '\'' +
                    ", extraParam='" + extraParam + '\'' +
                    ", amount=" + amount +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "PayResponse{" +
                "code=" + code +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }
}
