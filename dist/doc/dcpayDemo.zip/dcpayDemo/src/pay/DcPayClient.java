package src.pay;
import java.math.BigDecimal;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Base64;

public class DcPayClient {
    
    private final String baseUrl;
    private final String mchNo;
    private final String privateKey;
    private final HttpClient httpClient;

    public DcPayClient(String baseUrl, String mchNo, String privateKey) {
        this.baseUrl = baseUrl;
        this.mchNo = mchNo;
        this.privateKey = privateKey;
        this.httpClient = HttpClient.newHttpClient();
    }

    public PayResponse pay(PayRequest request) throws Exception {
        request.setMchNo(mchNo);
        request.setReqTime(System.currentTimeMillis());
        
        String signStr = buildSignString(request);
        System.out.println("待签名字符串: " + signStr);
        
        String sign = rsa2Sign(signStr, privateKey);
        request.setSign(sign);
        
        String jsonBody = toJson(request);
        System.out.println("请求JSON: " + jsonBody);
        System.out.println();
        
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/unipay/pay"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody, StandardCharsets.UTF_8))
                .build();
        
        HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        
        System.out.println("响应状态码: " + response.statusCode());
        System.out.println("响应内容: " + response.body());
        
        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP请求失败, 状态码: " + response.statusCode() + ", 响应: " + response.body());
        }
        
        return parseResponse(response.body());
    }

    public static String rsa2Sign(String data, String privateKeyStr) throws Exception {
        System.out.println("[签名] 原始数据: " + data);
        
        String privateKeyPEM = privateKeyStr
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replaceAll("\\s+", "");
        
        
        byte[] keyBytes = Base64.getDecoder().decode(privateKeyPEM);
        
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        PrivateKey privateKey = KeyFactory.getInstance("RSA").generatePrivate(keySpec);
        
        Signature signature = Signature.getInstance("SHA256WithRSA");
        signature.initSign(privateKey);
        signature.update(data.getBytes(StandardCharsets.UTF_8));
        
        byte[] signBytes = signature.sign();
        String signResult = Base64.getEncoder().encodeToString(signBytes);
        System.out.println("[签名] 签名结果: " + signResult);
        
        return signResult;
    }

    public static String buildSignString(PayRequest request) {
        Map<String, String> params = new HashMap<>();
        params.put("mchNo", request.getMchNo());
        params.put("bizOrderNo", request.getBizOrderNo());
        if (request.getAmount() != null) {
            // 使用 stripTrailingZeros 与服务端保持一致
            params.put("amount", request.getAmount().stripTrailingZeros().toPlainString());
        }
        params.put("currency", request.getCurrency());
        if (request.getReqTime() != null) {
            params.put("reqTime", String.valueOf(request.getReqTime()));
        }
        if (request.getTitle() != null) {
            params.put("title", request.getTitle());
        }
        if (request.getClientIp() != null) {
            params.put("clientIp", request.getClientIp());
        }
        if (request.getNotifyUrl() != null) {
            params.put("notifyUrl", request.getNotifyUrl());
        }
        if (request.getReturnUrl() != null) {
            params.put("returnUrl", request.getReturnUrl());
        }
        if (request.getExpiredTime() != null) {
            params.put("expiredTime", String.valueOf(request.getExpiredTime()));
        }
        if (request.getExtraParam() != null) {
            params.put("extraParam", request.getExtraParam());
        }
        
        return buildSignString(params);
    }

    public static String buildSignString(Map<String, String> params) {
        List<String> keys = new ArrayList<>(params.keySet());
        Collections.sort(keys);
        
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < keys.size(); i++) {
            String key = keys.get(i);
            String value = params.get(key);
            if (value != null && !value.isEmpty() && !"sign".equals(key)) {
                if (i > 0 && sb.length() > 0) sb.append("&");
                sb.append(key).append("=").append(value);
            }
        }
        return sb.toString();
    }

    private String toJson(PayRequest request) {
        StringBuilder json = new StringBuilder();
        json.append("{");
        
        List<String> fields = new ArrayList<>();
        addField(fields, "mchNo", request.getMchNo(), true);
        addField(fields, "bizOrderNo", request.getBizOrderNo(), true);
        if (request.getAmount() != null) {
            fields.add("\"amount\": " + request.getAmount().toPlainString());
        }
        addField(fields, "currency", request.getCurrency(), true);
        if (request.getReqTime() != null) {
            fields.add("\"reqTime\": " + request.getReqTime());
        }
        addField(fields, "sign", request.getSign(), true);
        addField(fields, "title", request.getTitle(), true);
        addField(fields, "clientIp", request.getClientIp(), true);
        addField(fields, "notifyUrl", request.getNotifyUrl(), true);
        addField(fields, "returnUrl", request.getReturnUrl(), true);
        if (request.getExpiredTime() != null) {
            fields.add("\"expiredTime\": " + request.getExpiredTime());
        }
        addField(fields, "extraParam", request.getExtraParam(), true);
        
        json.append(String.join(", ", fields));
        json.append("}");
        return json.toString();
    }

    private void addField(List<String> fields, String name, String value, boolean quoted) {
        if (value != null) {
            if (quoted) {
                fields.add("\"" + name + "\": \"" + escapeJson(value) + "\"");
            } else {
                fields.add("\"" + name + "\": " + value);
            }
        }
    }

    private String escapeJson(String value) {
        return value.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }

    private PayResponse parseResponse(String json) {
        PayResponse response = new PayResponse();
        
        String codeStr = extractNumericField(json, "code");
        if (codeStr != null) {
            response.setCode(Integer.parseInt(codeStr));
        }
        response.setMsg(extractStringField(json, "msg"));
        
        String dataJson = extractObjectField(json, "data");
        if (dataJson != null) {
            PayResponse.PayData data = new PayResponse.PayData();
            data.setBizOrderNo(extractStringField(dataJson, "bizOrderNo"));
            data.setOrderNo(extractStringField(dataJson, "orderNo"));
            data.setStatus(extractStringField(dataJson, "status"));
            data.setPayData(extractStringField(dataJson, "payData"));
            data.setExtraParam(extractStringField(dataJson, "extraParam"));
            
            String amountStr = extractNumericField(dataJson, "amount");
            if (amountStr != null) {
                data.setAmount(new BigDecimal(amountStr));
            }
            response.setData(data);
        }
        
        return response;
    }

    private String extractObjectField(String json, String fieldName) {
        String pattern = "\"" + fieldName + "\"";
        int start = json.indexOf(pattern);
        if (start == -1) return null;
        
        start += pattern.length();
        while (start < json.length() && (json.charAt(start) == ' ' || json.charAt(start) == ':' || json.charAt(start) == '\t' || json.charAt(start) == '\n')) {
            start++;
        }
        
        if (start >= json.length() || json.charAt(start) != '{') return null;
        start++;
        
        int braceCount = 1;
        int end = start;
        while (end < json.length() && braceCount > 0) {
            char c = json.charAt(end);
            if (c == '{') braceCount++;
            else if (c == '}') braceCount--;
            end++;
        }
        
        return json.substring(start, end - 1);
    }

    private String extractStringField(String json, String fieldName) {
        String pattern = "\"" + fieldName + "\"";
        int start = json.indexOf(pattern);
        if (start == -1) return null;
        
        start += pattern.length();
        while (start < json.length() && (json.charAt(start) == ' ' || json.charAt(start) == ':' || json.charAt(start) == '\t' || json.charAt(start) == '\n')) {
            start++;
        }
        
        if (start >= json.length() || json.charAt(start) != '"') return null;
        start++;
        
        int end = start;
        while (end < json.length()) {
            char c = json.charAt(end);
            if (c == '\\' && end + 1 < json.length()) {
                end += 2;
                continue;
            }
            if (c == '"') break;
            end++;
        }
        
        String value = json.substring(start, end);
        return value.replace("\\\"", "\"")
                   .replace("\\\\", "\\")
                   .replace("\\n", "\n")
                   .replace("\\r", "\r")
                   .replace("\\t", "\t");
    }

    private String extractNumericField(String json, String fieldName) {
        String pattern = "\"" + fieldName + "\"";
        int start = json.indexOf(pattern);
        if (start == -1) return null;
        
        start += pattern.length();
        while (start < json.length() && (json.charAt(start) == ' ' || json.charAt(start) == ':' || json.charAt(start) == '\t' || json.charAt(start) == '\n')) {
            start++;
        }
        
        int end = start;
        while (end < json.length() && (Character.isDigit(json.charAt(end)) || json.charAt(end) == '.' || json.charAt(end) == '-')) {
            end++;
        }
        
        return json.substring(start, end).trim();
    }
}
