package src.pay;
import java.math.BigDecimal;

public class PayExample {
    
    public static void main(String[] args) throws Exception {
        String baseUrl = "https://api.dcpay.me";
        String mchNo = "DC1010";
        String privateKey = "-----BEGIN PRIVATE KEY-----\n" +
                        "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAJwfnFLiEq2SyLgY\n" +
                        "fSSNv2yQ/PDmvQQ21MRLQvga3guxfql6582MPQGiV49EKCY6z4OfGsGbALmVQt1Y\n" +
                        "pbRq1bnqW0qUuG1K8ZHK+M4GpGgipVjPgCO5SKkYol2364DLKevxddB4F8ehVL07\n" +
                        "cC/QiN0uNgsHtIsSy18l2Lfq31I3AgMBAAECgYAh9f5bSTIm77cZ1LnkKbFqPF/J\n" +
                        "R2f2crb1vCllLvL+OC4FT+b8n3Tl1hqV342cQ07Aout/EeimdgGFhLMG+/Zhk81g\n" +
                        "NByjRDUkayMy2x1mNVOA8lB7VkTREKPyAEGwt4aLumxGI3AzrgAhDVXi9R4qaSRu\n" +
                        "ve8YBubbiYNrmLbGgQJBAMp6TEC1Z67CVT6uitExOTcfihNuvmqGBxtF+l4V+icq\n" +
                        "RykC/FfMXnfafbbbbAK42UdIRZKSMZKaPHFVtXMXKGMCQQDFZINUWxiO0SD14t09\n" +
                        "xw5neDDkjdiwKH+zbieDbclrjc62x0o4BzBOL5ADKeCgG+AkuQz1B4Wj1t/A4pg6\n" +
                        "0/UdAkAb1vLzFr45ziiQZMlbeAwo4yJGB70QwnrpqhaBpz3s8qg0IF/35na6vgT5\n" +
                        "BnR0b1wYq/w86fL8+E4FO0amm3GHAkB/OUlsFUq+wgt8b7wpFSMzjUP2C3aeE3w7\n" +
                        "KcRN8XTg3YVeSRSNCBUaT42CfHtKtqzA/oRbaX25G8UbjPCQ+gwBAkBsbCfGqVkD\n" +
                        "42aQP3HSn41F6EhpuK2IXtWGCjt0tdGt0ekbKNHS0H04rfYS/pjKuiZ+Y50xmtgL\n" +
                        "YoLNVkiIx8i5\n" +
                        "-----END PRIVATE KEY-----";
        
        DcPayClient client = new DcPayClient(baseUrl, mchNo, privateKey);
        
        PayRequest request = new PayRequest();
        // 必填
        request.setBizOrderNo("ORDER_" + System.currentTimeMillis());
        request.setAmount(new BigDecimal("100"));
        request.setCurrency("INR");

        // 选填
        request.setTitle("测试订单");
        request.setClientIp("127.0.0.1");
        request.setNotifyUrl("https://example.com/notify");
        request.setReturnUrl("https://example.com/return");
        request.setExpiredTime(System.currentTimeMillis() + 30 * 60 * 1000); // 30分钟后过期
        request.setExtraParam("随便传入任意数据");
        
        System.out.println("=== 发起支付请求 ===");
        System.out.println("商户号: " + mchNo);
        System.out.println("订单号: " + request.getBizOrderNo());
        System.out.println("金额: " + request.getAmount());
        System.out.println("货币: " + request.getCurrency());
        System.out.println();
        
        try {
            PayResponse response = client.pay(request);
            System.out.println("=== 支付响应 ===");
            System.out.println("响应码: " + response.getCode());
            System.out.println("响应消息: " + response.getMsg());
            if (response.getData() != null) {
                PayResponse.PayData data = response.getData();
                System.out.println("商户订单号: " + data.getBizOrderNo());
                System.out.println("DCPAY订单号: " + data.getOrderNo());
                System.out.println("支付状态: " + data.getStatus());
                System.out.println("支付金额（单位分）: " + data.getAmount());
                System.out.println("支付参数: " + data.getPayData());
            }
        } catch (Exception e) {
            System.err.println("支付请求失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
