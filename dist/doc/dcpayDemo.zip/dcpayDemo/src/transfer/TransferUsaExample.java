package src.transfer;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 代付下单示例 - 美国通道（货币 USD）
 * <p>
 * 美国代付通过 wayCode + wayParam 指定收款方式，二者均必填：
 * <ul>
 *   <li>wayCode 取值: ecashapp / paypal / venmo / emt / card / ach / chime / zelle
 *       （具体为某商户开通哪些以对接群 / 管理员确认为准）</li>
 *   <li>wayParam 为支付方式参数，随 wayCode 不同，字段见下方注释</li>
 * </ul>
 * 注意: wayParam 参与签名时需序列化为「key 升序」的紧凑 JSON，且与服务端一致地
 * 去除 " 与 \ 字符（TransferClient 已实现）。
 */
public class TransferUsaExample {

    public static void main(String[] args) throws Exception {
        String baseUrl = "https://api.dcpay.me";
        String mchNo = "DC2001";
        String privateKey = "-----BEGIN PRIVATE KEY-----\n" +
                        "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAJwfnFLiEq2SyLgY\n" +
                        "fSSNv2yQ/PDmvQQ21MRLQvga3guxfql6582MPQGiV49EKCY6z4OfGsGbALmVQt1Y\n" +
                        "pbRq1bnqW0qUuG1K8ZHK+M4GpGgipVjPgCO5SKkYol2364DLKevxddB4F8ehVL07\n" +
                        "cC/QiN0uNgsHtIsSy18l2Lfq31I3AgMBAAECgYAh9f5bSTIm77cZ1LnkKbFqPF/J\n" +
                        "R2f2crb1vCllLvL+OC4FT+b8n3Tl1hqV342cQ07Aout/EeimdgGFhLMG+/Zhk81g\n" +
                        "NByjRDUkayMy2x1mNVOA8lB7VkTREKPyAEGwt4aLumxGI3AzrgAhDVXi9R4qaSRu\n" +
                        "ve8YBubbiYNrmLbGgQJBAMp6TEC1Z67CVT6uitExOTcfihNuvmqGBxtF+l4V+icq\n" +
                        "RykC/FfMXnfafbbbbAK42UdIRZKSMZKaPHFVtXMXKGMCQQDFZINUWxiO0SD14t09\n" +
                        "xw5neDDkjdiwKH+zbieDbclrjc62x0o4BzBOL5ADKeCgG+AkuQz1B4Wj1t/A4pg6\n" +
                        "0/UdAkAb1vLzFr45ziiQZMlbeAwo4yJGB70QwnrpqhaBpz3s8qg0IF/35na6vgT5\n" +
                        "BnR0b1wYq/w86fL8+E4FO0amm3GHAkB/OUlsFUq+wgt8b7wpFSMzjUP2C3aeE3w7\n" +
                        "KcRN8XTg3YVeSRSNCBUaT42CfHtKtqzA/oRbaX25G8UbjPCQ+gwBAkBsbCfGqVkD\n" +
                        "42aQP3HSn41F6EhpuK2IXtWGCjt0tdGt0ekbKNHS0H04rfYS/pjKuiZ+Y50xmtgL\n" +
                        "YoLNVkiIx8i5\n" +
                        "-----END PRIVATE KEY-----";

        TransferClient client = new TransferClient(baseUrl, privateKey);

        TransferRequest request = new TransferRequest();
        // 必选  sign reqTime 必选参数的填入放到了 client.transfer(request) 方法中
        request.setMchNo(mchNo);
        request.setBizOrderNo("TRANSFER_US_" + System.currentTimeMillis());
        request.setAmount(new BigDecimal("100.00"));
        request.setCurrency("USD");

        // 可选
        request.setClientIp("1.1.1.1");
        request.setNotifyUrl("https://example.com/transfer/notify");
        request.setExtraParam("任意字符串");

        // 必填: 支付方式 + 支付方式参数。此处以 CashApp 个码为例
        request.setWayCode("ecashapp");
        Map<String, String> wayParam = new LinkedHashMap<>();
        wayParam.put("cashtag", "$YourTag");
        request.setWayParam(wayParam);

        // 其他支付方式示例（替换 wayCode 与 wayParam）:
        //   paypal/venmo/emt : wayParam = {"email": "payee@example.com"}
        //   card             : wayParam = {"cardNumber": "4111111111111111", "cardValid": "01/2028"}
        //   ach              : wayParam = {"accountNumber": "123456789012", "routingNumber": "026009593"}
        //   chime            : wayParam = {"chimeSign": "$test888"}
        //   zelle            : wayParam = {"zelleSign": "payee@example.com 或 +12125550000"}

        System.out.println("=== 发起代付请求(美国) ===");
        System.out.println("商户号: " + mchNo);
        System.out.println("订单号: " + request.getBizOrderNo());
        System.out.println("金额: " + request.getAmount());
        System.out.println("货币: " + request.getCurrency());
        System.out.println("支付方式: " + request.getWayCode());
        System.out.println("支付方式参数: " + request.getWayParam());
        System.out.println();

        try {
            TransferResponse response = client.transfer(request);
            System.out.println("=== 代付响应 ===");
            System.out.println("响应码: " + response.getCode());
            System.out.println("响应消息: " + response.getMsg());
            if (response.getData() != null) {
                TransferResponse.TransferData data = response.getData();
                System.out.println("商户订单号: " + data.getBizOrderNo());
                System.out.println("DCPAY订单号: " + data.getOrderNo());
                System.out.println("状态: " + data.getStatus());
                System.out.println("金额: " + data.getAmount());
            }
        } catch (Exception e) {
            System.err.println("代付请求失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
