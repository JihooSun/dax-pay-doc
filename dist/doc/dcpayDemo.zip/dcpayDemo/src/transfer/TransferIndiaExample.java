package src.transfer;

import java.math.BigDecimal;

/**
 * 代付下单示例 - 印度通道（货币 INR）
 * <p>
 * 印度代付使用银行账户 / IFSC / 传输模式(IMPS/NEFT/RTGS) 或 UPI(VPA) 指定收款方。
 */
public class TransferIndiaExample {

    public static void main(String[] args) throws Exception {
        String baseUrl = "https://api.dcpay.me";
        String mchNo = "DC1010";
        String privateKey = "-----BEGIN PRIVATE KEY-----\n" +
                        "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAJwfnFLiEq2SyLgY\n" +
                        "fSSNv2yQ/PDmvQQ21MRLQvga3guxfql6582MPQGiV49EKCY6z4OfGsGbALmVQt1Y\n" +
                        "pbRq1bnqW0qUuG1K8ZHK+M4GpGgipVjPgCO5SKkYol2364DLKevxddB4F8ehVL07\n" +
                        "cC/QiN0uNgsHtIsSy18l2Lfq31I3AgMBAAECgYAh9f5bSTIm77cZ1LnkKbFqPF/J\n" +
                        "R2f2crb1vCllLvL+OC4FT+b8n3Tl1hqV342cQ07Aout/EeimdgGFhLMG+/Zhk81g\n" +
                        "NByjRDUkayMy2x1mNVOA8lB7VkTREKPyAEGwt4aLumxGI3AzrgAhDVXi9R4qaSRu\n" +
                        "ve8YBubbiYNrmLbGgQJBAMp6TEC1Z67CVT6uitExOTcfihNuvmqGBxtF+l4V+icq\n" +
                        "RykC/FfMXnfafbbbbAK42UdIRZKSMZKaPHFVtXMXKGMCQQDFZINUWxiO0SD14t09\n" +
                        "xw5neDDkjdiwKH+zbieDbclrjc62x0o4BzBOL5ADKeCgG+AkuQz1B4Wj1t/A4pg6\n" +
                        "0/UdAkAb1vLzFr45ziiQZMlbeAwo4yJGB70QwnrpqhaBpz3s8qg0IF/35na6vgT5\n" +
                        "BnR0b1wYq/w86fL8+E4FO0amm3GHAkB/OUlsFUq+wgt8b7wpFSMzjUP2C3aeE3w7\n" +
                        "KcRN8XTg3YVeSRSNCBUaT42CfHtKtqzA/oRbaX25G8UbjPCQ+gwBAkBsbCfGqVkD\n" +
                        "42aQP3HSn41F6EhpuK2IXtWGCjt0tdGt0ekbKNHS0H04rfYS/pjKuiZ+Y50xmtgL\n" +
                        "YoLNVkiIx8i5\n" +
                        "-----END PRIVATE KEY-----";

        TransferClient client = new TransferClient(baseUrl, privateKey);

        TransferRequest request = new TransferRequest();
        // 必选  sign reqTime 必选参数的填入放到了 client.transfer(request) 方法中
        request.setMchNo(mchNo);
        request.setBizOrderNo("TRANSFER_" + System.currentTimeMillis());
        request.setAmount(new BigDecimal("1000.00"));
        request.setCurrency("INR");

        // 可选
        request.setTitle("代付转账");
        request.setClientIp("127.0.0.1");
        request.setNotifyUrl("https://example.com/transfer/notify");
        request.setExpiredTime(System.currentTimeMillis() + 30 * 60 * 1000);
        request.setExtraParam("任意字符串");
        request.setBankName("State Bank of India");
        request.setBranchName("Mumbai Branch");
        request.setAccountNo("1234567890123456");
        request.setAccountName("John Doe");
        request.setIfscCode("SBIN0001234");
        request.setTransferMode("IMPS");

        System.out.println("=== 发起代付请求(印度) ===");
        System.out.println("商户号: " + mchNo);
        System.out.println("订单号: " + request.getBizOrderNo());
        System.out.println("金额: " + request.getAmount());
        System.out.println("货币: " + request.getCurrency());
        System.out.println("银行: " + request.getBankName());
        System.out.println("收款人: " + request.getAccountName());
        System.out.println();

        try {
            TransferResponse response = client.transfer(request);
            System.out.println("=== 代付响应 ===");
            System.out.println("响应码: " + response.getCode());
            System.out.println("响应消息: " + response.getMsg());
            if (response.getData() != null) {
                TransferResponse.TransferData data = response.getData();
                System.out.println("商户订单号: " + data.getBizOrderNo());
                System.out.println("DCPAY订单号: " + data.getOrderNo());
                System.out.println("状态: " + data.getStatus());
                System.out.println("金额: " + data.getAmount());
            }
        } catch (Exception e) {
            System.err.println("代付请求失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
