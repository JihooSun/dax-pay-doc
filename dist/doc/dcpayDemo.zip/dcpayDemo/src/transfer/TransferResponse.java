package src.transfer;

import java.math.BigDecimal;

public class TransferResponse {
    private int code;
    private String msg;
    private TransferData data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public TransferData getData() {
        return data;
    }

    public void setData(TransferData data) {
        this.data = data;
    }

    public static class TransferData {
        private String bizOrderNo;
        private String orderNo;
        private String status;
        private String payData;
        private String extraParam;
        private BigDecimal amount;

        public String getBizOrderNo() {
            return bizOrderNo;
        }

        public void setBizOrderNo(String bizOrderNo) {
            this.bizOrderNo = bizOrderNo;
        }

        public String getOrderNo() {
            return orderNo;
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getPayData() {
            return payData;
        }

        public void setPayData(String payData) {
            this.payData = payData;
        }

        public String getExtraParam() {
            return extraParam;
        }

        public void setExtraParam(String extraParam) {
            this.extraParam = extraParam;
        }

        public BigDecimal getAmount() {
            return amount;
        }

        public void setAmount(BigDecimal amount) {
            this.amount = amount;
        }
    }
}
